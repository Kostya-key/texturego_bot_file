export function normalizeLighting(buffer) {
  return buffer;
}
