export function makeSeamless(buffer) {
  return buffer;
}
